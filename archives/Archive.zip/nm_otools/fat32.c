#include "nm.h"

int fat32(void *file)
{
	(void )(file);
	return 0;
}
