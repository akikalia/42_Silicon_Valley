#include "nm.h"

int fat64(void *file)
{
	(void)file;
	return 0;
}
